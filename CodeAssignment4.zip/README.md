# Group 1 Assignment 4
### Tim: Prototype, Adapter, Command
To run my code you can simply just use the python interpretter or g++ for the .cpp
```
python3 file.py
g++ file.cpp && ./a.out
```

